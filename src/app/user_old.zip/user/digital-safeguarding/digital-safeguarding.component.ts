import { Component } from '@angular/core';

@Component({
  selector: 'app-digital-safeguarding',
  templateUrl: './digital-safeguarding.component.html',
  styleUrls: ['./digital-safeguarding.component.css']
})
export class DigitalSafeguardingComponent {

  constructor(){

  }

  ngOnInit():void{
    window.scrollTo(0,0);
  }



}
