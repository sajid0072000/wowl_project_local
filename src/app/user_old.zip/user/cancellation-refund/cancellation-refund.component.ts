import { Component } from '@angular/core';

@Component({
  selector: 'app-cancellation-refund',
  templateUrl: './cancellation-refund.component.html',
  styleUrls: ['./cancellation-refund.component.css']
})
export class CancellationRefundComponent {

  constructor(){

  }

  ngOnInit():void{
    window.scrollTo(0,0);
  }

}
